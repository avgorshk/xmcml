// EasyTestPlugIn.cpp : Defines the entry point for the DLL application.
//

#include <cppunit/plugin/TestPlugIn.h>


// Implements all the plug-in stuffs, WinMain...
CPPUNIT_PLUGIN_IMPLEMENT();
